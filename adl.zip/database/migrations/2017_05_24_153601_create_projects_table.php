<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProjectsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('projects',function(Blueprint $table){
            $table->increments('project_id');
            
            $table->string('projectName')->unique();
            $table->integer('architectByID')->unsigned()->nullable();
            $table->integer('categoryID')->unsigned();

            $table->string('createdBy')->nullable();
            $table->string('structure');
            $table->string('siteArea');
            $table->string('GFA');
            $table->string('description');
            $table->string('fileList')->nullable();
            
            $table->timestamps();

            $table->foreign('categoryID')->references('id')->on('categories')->onUpdate('cascade');

            $table->foreign('architectByID')->references('id')->on('users')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('projects');
    }
}
