<?php

namespace Pmptadl;

use Illuminate\Database\Eloquent\Model;

class projectLibrary extends Model
{
	//
}
