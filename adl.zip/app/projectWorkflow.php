<?php

namespace Pmptadl;

use Illuminate\Database\Eloquent\Model;

class projectWorkflow extends Model
{
    protected $table = 'projectWorkflow';
}
