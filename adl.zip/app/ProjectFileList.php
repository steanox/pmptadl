<?php

namespace Pmptadl;

use Illuminate\Database\Eloquent\Model;

class ProjectFileList extends Model
{
    protected $table = 'projectfilelists';
}
