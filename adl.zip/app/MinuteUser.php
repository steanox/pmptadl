<?php

namespace Pmptadl;

use Illuminate\Database\Eloquent\Model;

class MinuteUser extends Model
{
    protected $table = 'minuteUsers';
}
