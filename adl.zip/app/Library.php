<?php

namespace Pmptadl;

use Illuminate\Database\Eloquent\Model;

class Library extends Model
{
    protected $table = 'projectFileTransferHistory';
}
