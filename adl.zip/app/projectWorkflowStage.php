<?php

namespace Pmptadl;

use Illuminate\Database\Eloquent\Model;

class projectWorkflowStage extends Model
{
     protected $table = 'projectWorkflowStages';
}
