<?php

namespace Pmptadl\Http\Controllers;

use Pmptadl\Project;
use Pmptadl\User;
use Pmptadl\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Validation\ValidatesRequests;

class projectController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $data = array(
            "title" => ["project"],
            "css" => array(
                "js/jstree/dist/themes/default/style.min.css"
            ),
            "js" => array(
                "js/jstree/dist/jstree.min.js",
                "js/ui-tree.js"
            )
        );
       
        $data['projects'] = Project::with('category')->get();
        return view('project',$data);
    }

    public function createProject(){

        $data = array(
            "title" => ["project","add new project"],
            "css" => array(
                "js/select2/select2.css",
                
            ),
            "js" => array(
                "js/select2/select2.js",
                "js/components-dropdowns.js"
            )
        );

        $data['architectList'] = User::where('userType','architect')->orderBy('firstName','asc')->get();
        $data['categories'] = Category::orderBy('name','asc')->get();
        
        return view('add-new-project',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function createUser()
    {

        $data = array(
            "title" => ["project","add new user"]
        );

        return view('add-new-user',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $this->validate($request, [
            'projectName' => 'required',
            'projectDesc' => 'required',
            'projectSiteArea' => 'required',
            'projectGFA' => 'required',
            'projectStructure' => 'required',
        ]);
           
        $newProject = new Project();
        $newProject->projectName = $request->projectName;
        $newProject->description = $request->projectDesc;
        $newProject->siteArea    = $request->projectSiteArea;
        $newProject->GFA         = $request->projectGFA;
        $newProject->structure   = $request->projectStructure;
        $newProject->architectByID = $request->architectByID;
        $newProject->categoryID = $request->categoryID;
        $newProject->createdBy   = '{"id":'.Auth::user()->id.',"name":"'.Auth::user()->name.'"}';

        if($newProject->save()){
            $request->session()->flash('status','successfully create new project');
            return redirect()->route('projects');
        }
        else{
            print("die");
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \Pmptadl\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function show(Project $project)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \Pmptadl\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function edit(Project $project)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Pmptadl\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Project $project)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \Pmptadl\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function destroy(Project $project)
    {
        //
    }
}
