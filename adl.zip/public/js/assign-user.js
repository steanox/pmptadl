
    function hash(str, hashSize)
    {
        var result = 0; 
        
        for(var i = 0; i < str.length; i++) 
            result += str.charCodeAt(i) + 31 * result;
        
        return result % hashSize;
    }

    $('#assign-user')
        .textext({
            plugins : 'tags autocomplete',

            autocomplete : {
                dropdownMaxHeight : '200px',

                render : function(suggestion)
                {
                    // `this` refers to the instance of `TextExtAutocomplete`
                    var icons = 'exclamation feed house information lock'.split(/ /g),
                        icon  = icons[hash(suggestion, icons.length)]
                        ;

                    return '<div style="background-image:url(https://dummyimage.com/20x20/000/fff)">' + suggestion +
                        '<p>Lorem ipsum dolor sit amet, consectetur adipisicing ' +
                        'elit...</p></div>';
                }
            }
        })
        .bind('getSuggestions', function(e, data)
        {
             var list = [
                 'Agung suryadi',
                 'Sabrina levita',
                 'Bellana',
                 'Delphi',
                 'Chandra Winata',
                 'Kevin',
                 'Go para',
                 'Agus ganda',
                 'Tan mei fu',
                 'Javani',
                 'Axel ad'
             ],
                textext = $(e.target).textext()[0],
                query = (data ? data.query : '') || ''
                ;

            $(this).trigger(
                'setSuggestions',
                { result : textext.itemManager().filter(list, query) }
            );
        })
        ;
